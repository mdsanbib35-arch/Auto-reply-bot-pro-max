/* Command: onVoice */
if (request.voice) {
  let fileId = request.voice.file_id;

  Api.sendChatAction({
    chat_id: chat.chat_id,
    action: "record_voice"
  });

  let botToken = "8758680808:AAGGbp3S4LCg9vZdqwPf2IivrOCLge7Bffg";
  
  HTTP.get({
    url: "https://api.telegram.org/bot" + botToken + "/getFile?file_id=" + fileId,
    success: "/onGetVoiceFile"
  });
}
