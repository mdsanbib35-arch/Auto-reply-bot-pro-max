/* Command: /onGetVoiceFile */
let fileData = JSON.parse(content);

if (fileData.ok && fileData.result.file_path) {
  let botToken = "8758680808:AAGGbp3S4LCg9vZdqwPf2IivrOCLge7Bffg";
  let apiKey = "AQ.Ab8RN6L3ZyLh4oDhOIfj5ziGCRA167waWpbOq3omTwtywNEeYg";
  
  let fileDownloadUrl = "https://api.telegram.org/file/bot" + botToken + "/" + fileData.result.file_path;

  let url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + apiKey;

  let payload = {
    contents: [
      {
        parts: [
          {
            text: "Listen carefully to this voice message, understand the language, and answer the user directly and concisely in the same language."
          }
        ]
      }
    ]
  };

  HTTP.post({
    url: url,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
    success: "/onGeminiTextReply",
    error: "/onGeminiError"
  });
} else {
  Bot.sendMessage("ভয়েস ফাইল প্রসেস করতে সমস্যা হচ্ছে।");
}
