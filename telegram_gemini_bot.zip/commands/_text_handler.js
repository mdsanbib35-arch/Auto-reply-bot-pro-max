/* Command: * (Wildcard Text Handler) */
let userText = message;

if (userText && !userText.startsWith("/")) {
  Api.sendChatAction({
    chat_id: chat.chat_id,
    action: "typing"
  });

  let apiKey = "AQ.Ab8RN6L3ZyLh4oDhOIfj5ziGCRA167waWpbOq3omTwtywNEeYg";
  let url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + apiKey;

  let payload = {
    contents: [
      {
        parts: [
          {
            text: "You are a helpful, witty, and accurate AI assistant. Reply naturally in the same language the user uses. User message: " + userText
          }
        ]
      }
    ]
  };

  HTTP.post({
    url: url,
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload),
    success: "/onGeminiTextReply",
    error: "/onGeminiError"
  });
}
