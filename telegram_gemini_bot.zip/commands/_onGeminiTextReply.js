/* Command: /onGeminiTextReply */
let result = JSON.parse(content);

if (result && result.candidates && result.candidates[0].content.parts[0].text) {
  let aiReply = result.candidates[0].content.parts[0].text;
  Bot.sendMessage(aiReply);
} else {
  Bot.sendMessage("দুঃখিত, কোনো উত্তর তৈরি করা সম্ভব হয়নি। আবার চেষ্টা করুন।");
}
