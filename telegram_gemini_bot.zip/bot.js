// Standalone Node.js bot for 24/7 Hosting (Render, Koyeb, Termux, VPS)
const { Telegraf } = require('telegraf');
const axios = require('axios');

const BOT_TOKEN = process.env.BOT_TOKEN || '8758680808:AAGGbp3S4LCg9vZdqwPf2IivrOCLge7Bffg';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || 'AQ.Ab8RN6L3ZyLh4oDhOIfj5ziGCRA167waWpbOq3omTwtywNEeYg';

const bot = new Telegraf(BOT_TOKEN);

bot.start((ctx) => {
  ctx.reply('হ্যালো! আমি আপনার স্মার্ট এআই বট। আমাকে যেকোনো প্রশ্ন করতে পারেন যেকোনো ভাষায়!');
});

bot.on('text', async (ctx) => {
  const userText = ctx.message.text;
  await ctx.sendChatAction('typing');

  try {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`;
    const response = await axios.post(url, {
      contents: [{
        parts: [{ text: `You are an AI assistant. Answer accurately in the user's language. User: ${userText}` }]
      }]
    });

    const reply = response.data.candidates[0].content.parts[0].text;
    await ctx.reply(reply);
  } catch (err) {
    console.error(err);
    await ctx.reply('দুঃখিত, উত্তর প্রসেস করতে সমস্যা হয়েছে।');
  }
});

bot.launch().then(() => {
  console.log('Bot is running 24/7...');
});

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
