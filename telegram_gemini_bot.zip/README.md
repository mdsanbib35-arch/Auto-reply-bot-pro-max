# Telegram Gemini AI Auto-Reply Bot

এই রিপোজিটরিতে টেলিগ্রাম অটো-রিপ্লাই বট-এর সম্পূর্ণ কোড রয়েছে।

## যা যা যুক্ত আছে:
1. **Bot.business Commands (BJS)**: Bot.business এর জন্য প্রস্তুতকৃত কমান্ড ফাইলসমূহ (`commands/` ফোল্ডারে)।
2. **Node.js Bot (Standalone / Cloud)**: Render, Koyeb, Replit অথবা VPS/Termux-এ ২৪/৭ চালু রাখার জন্য `bot.js`।

---

## সেটআপ গাইড (ধাপে ধাপে):

### পদ্ধতি ১: Bot.business দিয়ে সেটআপ
1. Bot.business ওয়েবসাইটে গিয়ে লগইন করুন এবং একটি নতুন বট তৈরি করুন।
2. বটের Settings-এ গিয়ে আপনার টেলিগ্রাম বট টোকেন দিন।
3. `commands/` ফোল্ডারের ফাইলগুলোর কোড কপি করে Bot.business-এর Commands সেকশনে যুক্ত করুন অথবা Git Sync অপশন ব্যবহার করে আপনার GitHub রিপোজিটরি লিংক করে দিন।

### পদ্ধতি ২: সরাসরি Node.js (GitHub + Render/Koyeb) দিয়ে ২৪/৭ রান
1. GitHub-এ এই ফাইলগুলো আপলোড করুন।
2. Render.com বা Koyeb.com-এ ফ্রি একাউন্ট খুলে Web Service বা Worker হিসেবে গিটহাব রিপোজিটরিটি কানেক্ট করুন।
3. Environment Variable-এ সেট করুন:
   - `BOT_TOKEN`: আপনার টেলিগ্রাম বট টোকেন
   - `GEMINI_API_KEY`: আপনার জেমিনি এপিআই কি
4. অটোমেটিক ২৪/৭ ব্যাকগ্রাউন্ডে চলবে!
